---
layout: post
section: "Notes On Human Complexity"
title: "Cooperation-Based Organizations: Six Simple Rules"
position: 7007
podcast: six-simple-rules.mp3
spotify: https://open.spotify.com/episode/3w1SxajFCOgJ80oIdubQE7?si=8028da4b439d4fe9
date:   2021-10-21 21:12:01 +0100
author: by Željko Obrenović (obren.io)
icon: org-alignment.png
permalink: six-simple-rules
timetoread: 11 min
excerpt: "Grounded Architecture applies the Six Simple Rules to manage complexity by balancing autonomy and cooperation. Instead of relying on rigid processes or soft sentiment alone, it fosters structures that empower individuals and promote collaboration. Key principles like reinforcing integrators, increasing power, and rewarding cooperation enable distributed decision-making."

---

<img style="margin-top: -20px; width: 100%; height: 400px; object-fit: cover" 
     src="assets/images/istock/iStock-2031547179.jpg">
<div style="font-size: 70%; margin-top: -16px; color: grey; margin-bottom: 12px">
Image by <a target="_blank" href="https://www.istockphoto.com/en/portfolio/NanoStockk">NanoStockk</a> from <a target="_blank" href="https://www.istockphoto.com/">iStock</a>
</div>
<style>
 .quote {
     border-left: 8px solid #d9ead3;
     padding-left: 36px;
     margin-top: 30px;
     margin-bottom: 40px;
     font-size: 140%;
     font-style: normal;
     color:#888;
 }
    @media only screen and (max-width: 768px) {
        [class="quote"] {
            display: none;
        }
    }
</style>

> **IN THIS SECTION, YOU WILL:**  Get an introduction to Six Simple Rules, a model for setting up organizational structures based on cooperation.
>
> **KEY POINTS:**
>
> * Grounded Architecture emphasizes collaboration and aligns with the Six Simple Rules framework, which promotes autonomy and cooperation to manage organizational complexity effectively.
> * The Six Simple Rules reject traditional hard and soft management styles, instead advocating for structures that empower people while encouraging mutual accountability and cooperation.
> * Key rules include understanding actual work behaviors, reinforcing integrators, and increasing the total power in the organization to enable decision-making without creating bureaucracy.
> * Cooperation is strengthened through reciprocity, feedback loops ("shadow of the future"), and rewarding collaborative behavior, creating a system where shared success drives performance.
> * Architecture practices play a vital role by using tools like Lightweight Architectural Analytics and Collaborative Networks to support these rules and foster an adaptive, high-impact environment.


<br>
The Grounded Architecture operating model is **fundamentally collaborative**. It focuses on establishing **organizational structures based on cooperation**, allowing architects to work effectively with others and make a meaningful impact. To foster such a collaborative approach, I have found the Six Simple Rules method, developed by Yves Morieux and Peter Tollman, to be particularly useful. This framework encourages organizations to adapt to complexity by promoting autonomy and cooperation among their members.

The book *Six Simple Rules: How to Manage Complexity Without Getting Complicated* by Yves Morieux and Peter Tollman has greatly influenced my vision of an architectural practice. The authors introduce the concept of **Smart Simplicity**, outlining six rules or strategies that enable organizations to encourage new behaviors and enhance performance. The Six Simple Rules approach emphasizes that in today's business environment, it is essential to create **organizational structures based on cooperation**.

<div class="quote">
In today's complicated business environments, it is crucial to establish organizational structures that prioritize cooperation.
</div>

Morieux and Tollman developed the Six Simple Rules as a practical solution for today’s complex business landscape. The rules in the book rest on the idea that effectively managing complexity requires a **combination of autonomy and cooperation.** They advocate for organizational structures that align with this principle, empowering individuals to act autonomously. This approach is rooted in trusting the skills and capabilities of the organization's people to tackle complex challenges, thereby fostering a cooperative and efficient work environment.

In this chapter, I will explore how Grounded Architecture and the Six Simple Rules complement each other. The ideas from the Six Simple Rules have been a significant source of inspiration for my work. [**Conway's Law**](https://martinfowler.com/bliki/ConwaysLaw.html) illustrates that the relationship between organizational structures and IT architecture is like peanut butter and jelly—stronger and better together. Both the Six Simple Rules approach and architectural practice focus on managing complexity without becoming overwhelmed.

<br>
## Background: Hard and Soft Management

One of the Six Simple Rules' central premises is that **conventional management approaches**, which the authors split into hard and soft, are neither sufficient nor appropriate for the complexity of organizations nowadays.  

### Hard Approach

The **hard approach** rests on two fundamental assumptions:
 * The first is the belief that **structures, processes, and systems** have a direct and predictable effect on performance, and as long as managers pick the right ones, they will get the performance they want. 
 * The second assumption is that the **human factor is the weakest and least reliable link** of the organization and that it is essential to **control people’s behavior through the proliferation of rules** to specify their actions and through financial incentives linked to carefully designed metrics and key performance indicators (KPIs) to motivate them to perform in the way the organization wants them to. 
 
 When the company needs to meet new performance requirements, the **hard response** is to **add new structures, processes, and systems** to help satisfy those requirements. Hence, introducing the innovation czar, the risk management team, the compliance unit, the customer-centricity leader, and the cohort of coordinators and interfaces have become so common in companies.

![](assets/images/istock/iStock-936995400.jpg)
<div style="font-size: 70%; margin-top: -16px; color: grey; margin-bottom: 12px">
Image by <a target="_blank" href="https://www.istockphoto.com/en/portfolio/cyano66">cyano66</a> from <a target="_blank" href="https://www.istockphoto.com/">iStock</a>
</div>


In my experience, IT architecture support  in organizations following a hard management approach has the following characteristics:
* **Heavy Reliance on Tools:** The architecture would focus on tools, automation, and workflows that **enforce compliance,** standardization, and control. There might be a strong reliance on enterprise resource planning (ERP) systems, centralized data warehouses, and other structured tools that enable **strict adherence** to predefined processes.
* **Security and Compliance:** There would be a significant emphasis on **compliance frameworks,** security protocols, and risk management systems. These systems would be designed to ensure that all actions are traceable, compliant with regulations, and aligned with the company’s **predefined rules and processes.**
* **Bureaucratic Systems:** The architecture might include multiple **layers of control** and coordination units, such as a risk management system, compliance databases, and innovation management software. Each of these units would be designed to enforce specific aspects of the organization’s performance objectives.

### Soft Approach

On the other end, we have a soft management approach. According to the **soft approach**, an organization is a set of **interpersonal relationships and the sentiments** that govern them. 
* **Good performance is the by-product of good interpersonal relationships**. Personal traits, psychological needs, and mindsets predetermine people's actions. 
* To change behavior at work, you need to **change the mindset (or change the people)**. 

![](assets/images/istock/iStock-1482584637.jpg)
<div style="font-size: 70%; margin-top: -16px; color: grey; margin-bottom: 12px">
Image by <a target="_blank" href="https://www.istockphoto.com/en/portfolio/AlessandroBiascioli">Alessandro Biascioli</a> from <a target="_blank" href="https://www.istockphoto.com/">iStock</a>
</div>

In my experience, IT architecture support in organizations following a soft management approach has the following characteristics:
* **Employee Empowerment:** Systems would likely be designed to empower employees by providing the tools they need to **succeed independently,** such as access to real-time data, **self-service** analytics, and systems that encourage innovation and creativity.
* **Employee-Centric:** The architecture would focus on tools facilitating communication and **knowledge sharing.** These tools might include **collaboration platforms,** social intranets, and user-friendly interfaces that enable employees to interact more effectively.
* **Personalization:** Systems might be more personalized, offering **customization options** that align with individual preferences and needs. This personalization could include customizable dashboards and personalized workspaces.



<br>
## Collaboration Approach 

Hard and soft management approaches are limited in today's world and are harmful to cooperation. A **hard approach** introduces **complicated mechanisms**, compliance, and "checking the box" behaviors instead of the engagement and initiative to make things work. The **soft approach's** emphasis on **good interpersonal feelings** creates **cooperation obstacles** as people want to maintain good feelings.

The Six Simple Rules approach emphasizes that in today's business environment, you must set up **organizational structures based on cooperation**. More specifically, the Six Simple Rules approach involves the interplay of **autonomy** and **cooperation**. The authors emphasize the critical difference between autonomy and self-sufficiency. **Autonomy** is about fully mobilizing our intelligence and energy to **influence outcomes**, including those **we do not entirely control**. **Self-sufficiency** is about **limiting our efforts** only to those outcomes that we **control entirely without depending** on others. Autonomy is essential for coping with complexity; **self-sufficiency** is an obstacle because it **hinders the cooperation** needed to make autonomy effective.  

The first three rules create the conditions for **individual autonomy and empowerment** to improve performance.

* **Understand what your people do**. Trace performance back to behaviors and how they influence overall results. Understand the context of goals, resources, and constraints. Determine how an organization’s elements shape goals, resources, and constraints.
* **Reinforce integrators**. Identify integrators—those individuals or units whose influence makes a difference in the work of others—by looking for points of tension where people are doing the hard work of cooperating. Integrators bring others together and drive processes.
* **Increase the total quantity of power**. When creating new roles in the organization, empower them to make decisions without taking power away from others.


This difference between **Autonomy** and **Self-Sufficiency** leads us to the second set of rules that compels people to confront complexity and use their newfound autonomy to cooperate with others so that **overall performance, not just individual performance**, is radically improved.
* **Increase reciprocity**. Set clear objectives that stimulate mutual interest to cooperate. Make each person’s success dependent on the success of others. Eliminate monopolies, reduce resources, and create new networks of interaction.
* **Extend the shadow of the future**. Have people experience the consequences that result from their behavior and decisions. Tighten feedback loops. Shorten the duration of projects. Enable people to see how their success is aided by contributing to the success of others.
* **Reward those who cooperate**. Increase the payoff for all when they cooperate in a beneficial way. Establish penalties for those who fail to cooperate.



<br>
## Rule 1: Understand What Your People Do

The first rule states that you must genuinely understand performance: **what people do** and **why they do it**. When you know why people do what they do and how it drives performance, you can define the minimum sufficient set of **interventions with surgical accuracy**. 
 
![](assets/images/istock/iStock-1179186162.jpg)
<div style="font-size: 70%; margin-top: -16px; color: grey; margin-bottom: 12px">
Image by <a target="_blank" href="https://www.istockphoto.com/en/portfolio/scyther5">scyther5</a> from <a target="_blank" href="https://www.istockphoto.com/">iStock</a>
</div>

### Guidelines for Understanding Performance

To genuinely understand performance, consider the following principles:

* Trace performance back to behaviors, understanding how these behaviors influence and combine to produce overall results.
* Utilize observation, mapping, measurement, and discussion to gain insights.
* Comprehend the context of goals, resources, and constraints within which current behaviors are rational strategies for people.
* Discover how your organization's elements—structure, scorecards, systems, and incentives—shape these goals, resources, and constraints.

### Leveraging Architecture Practice

Architecture practice can significantly aid in understanding organizational behaviors through:

* Establishing a **[Lightweight Architectural Analytics](analytics)** with an overview of various data sources to reveal where activities occur, visible trends, and cooperation among people.
* Utilizing the **[Collaborative Networks](people)** to connect individuals and enable them to learn about activities in different parts of the organization.

<br>
## Rule 2: Reinforce Integrators

The Six Simple Rules approach emphasizes the importance of reinforcing integrators by looking at those **directly involved in the work**, giving them **power and interest to foster cooperation in dealing with complexity** instead of resorting to the paraphernalia of overarching hierarchies, overlays, dedicated interfaces, balanced scorecards, or coordination procedures.
 
![](assets/images/arch/agree-g1f407320e_1920.png)
<div style="font-size: 70%; margin-top: -16px; color: grey; margin-bottom: 12px">
Image by <a href="https://pixabay.com/users/shutterbug75-2077322/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=1238964">Robert Owen-Wahl</a> from <a href="https://pixabay.com//?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=1238964">Pixabay</a>
</div>

### Guidelines for Reinforcing Integrators

To strengthen integrators within your organization, consider these strategies:

* **Use emotions** to identify candidates. Feelings provide crucial clues for analysis and can act as symptoms of integration issues.
* **Identify operational units** that can be integrators among peer units due to their specific interests or power.
* **Remove managerial layers** that do not add value and reinforce others as integrators by eliminating specific rules and relying on observation and judgment over metrics when cooperation is involved.

### Enhancing Integrators Through Architecture Practice

Architecture practice can play a vital role in reinforcing integrators by:

* Utilizing the **[Collaborative Networks](people)** to help identify and connect integrators, leveraging their work effectively.
* Emphasizing architects as critical integrators and integrator role models within the organization, defining them as essential components of the organizational "[superglue](superglue)."
* Establishing a **[Lightweight Architectural Analytics](analytics)** to support integrators with data and insights, enabling them to perform more informed and effective work.

<br>
## Rule 3: Increase the Total Quantity of Power

Whenever you consider an **addition to** your organization’s **structure, processes, and systems**, think about **increasing the quantity of power**. Doing so may **save you from increasing complicatedness** and enable you to achieve a more significant impact with less cost. You can increase the quantity of power by allowing some functions to influence performance and stakes that matter to others. 


![](assets/images/istock/iStock-1201215883.jpg)
<div style="font-size: 70%; margin-top: -16px; color: grey; margin-bottom: 12px">
Image by <a target="_blank" href="https://www.istockphoto.com/en/portfolio/Milkos">Prostock-Studio</a> from <a target="_blank" href="https://www.istockphoto.com/">iStock</a>
</div>

### Guidelines for Increasing Power Quantity

To enhance the quantity of power within your organization, consider these actions recommended by the Six Simple Rules approach:

* When making design decisions that could shift the balance between central and unit power, functions, and line managers, ensure that some parts of the **organization benefit from new power bases.** This approach helps meet complexity requirements and avoids future disruptions from pendulum swings.
* When creating new functions, ensure they have the power to fulfill their roles **without diminishing the power others need** to fulfill theirs.
* When introducing new tools for managers, such as planning or evaluation systems, evaluate whether these tools **act as resources or constraints.** Implementing a few tools creates a critical mass of power, which is more effective than introducing many tools sequentially.
* Regularly **enrich power bases** to maintain agility, flexibility, and adaptability.

### Enhancing Power Quantity Through Architecture Practice

Architecture practice can support the increase in power quantity through an operating model that promotes distributed decision-making:

* Through the **[Collaborative Networks](people)**, you can enhance decision-making power by distributing architectural decision-making across the organization and embedding it within development teams, which typically have the best insights and most relevant information.
* Additionally, **[Lightweight Architectural Analytics](analytics)**, accessible to all interested members of the organization, can provide data and insights that empower individuals in their daily work.


<br>
## Rule 4: Increase Reciprocity

In the face of business complexity, work is becoming more interdependent. To meet multiple and often contradictory performance requirements, **people must rely more on each other**. They need to **cooperate directly** instead of depending on dedicated interfaces, coordination structures, or procedures that only add to complicatedness. 

<img src="assets/images/istock/iStock-1072898930.jpg" style="width: 100%">
<div style="text-align: center; font-size: 70%; color: grey; margin-bottom: 12px; margin-top: -12px;">
Image by <a target="_blank" href="https://www.istockphoto.com/en/portfolio/Natnan_Srisuwan">Natnan Srisuwan</a> from <a target="_blank" href="https://www.istockphoto.com/">iStock</a>
</div>

### Guidelines for Enhancing Reciprocity

Reciprocity involves recognizing that people or units in an organization have a mutual interest in cooperation and that the success of one depends on the success of others. To foster this reciprocity, follow these guidelines:

* **Eliminate monopolies** to ensure no single entity has exclusive control.
* **Reduce resources** to encourage more efficient and collaborative use.
* **Create new networks** of interaction to facilitate better communication and cooperation.

### Enhancing Reciprocity Through Architecture Practice

Architecture practice can significantly increase reciprocity within an organization:

* The **[Collaborative Networks](people)** supports creating new networks of interactions, directly reinforcing reciprocity.
* A [hybrid operating model](operating-model) relies on the mutual success of an architecture practice and development teams. Architects' [impact](impact) is essential, and their support depends on the feedback from the groups they assist. Integrating this feedback into architects' performance evaluations is crucial for enhancing reciprocity between architecture and other units.

<br>
## Rule 5: Extend the Shadow of the Future

The Six Simple Rules approach emphasizes the importance of making visible and clear **what happens tomorrow as a consequence of what they do today**.
 

![](assets/images/arch/trees-gc38b3c617_1920.jpg)
<div style="font-size: 70%; margin-top: -16px; color: grey; margin-bottom: 12px">
Image by <a href="https://pixabay.com/users/jplenio-7645255/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=3294681">Joe</a> from <a href="https://pixabay.com//?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=3294681">Pixabay</a>
</div>


### Guidelines for Extending the Shadow of the Future

The Six Simple Rules approach recommends four strategies to extend the shadow of the future:

* **Tighten the feedback loop** by increasing the frequency of moments when people experience the consequences of the fit between their contributions.
* **Bring the endpoint forward** by shortening the duration of projects.
* **Tie futures together** so that successful moves are conditioned on contributing to the success of others.
* Ensure people **walk in the shoes they make** for others.

### Extending the Shadow of the Future Through Architecture Practice

Architecture practice can play a crucial role in extending the shadow of the future through various methods:

* **[Lightweight Architectural Analytics](analytics)** can create transparency and provide the data necessary to model the future. This data can be used to develop simulations and roadmap options.
* Applying **[economic modeling](economics)** to architecture decision-making helps describe the future consequences of today's actions, directly supporting long-term planning and decision-making.


<br>
## Rule 6: Reward Those Who Cooperate

Lastly, the Six Simple Rules approach recommends that when you cannot create direct feedback loops embedded in people’s tasks, you need **management’s intervention to close the loop**. Managers must then use the familiar performance evaluation tool but in a very different way to reward those who cooperate. 


![](assets/images/arch/people-gac98109e9_1920.jpg)
<div style="font-size: 70%; margin-top: -16px; color: grey; margin-bottom: 12px">
Image by <a href="https://pixabay.com/users/stocksnap-894430/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=2569234">StockSnap</a> from <a href="https://pixabay.com//?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=2569234">Pixabay</a>
</div>

### Guidelines for Rewarding Cooperation

To effectively reward those who cooperate, managers should:

* **Go beyond technical criteria** and avoid placing blame solely on where the root cause originated. Accept that execution problems arise from various reasons. The smart approach is to reduce rewards for those who **fail to cooperate** in solving a problem, even if the problem isn't in their direct area, and increase rewards for units that cooperate beneficially.
* **Avoid blaming failure** and instead focus on blaming the inability to **help or seek help.**
* **Use simple questions** to shift managerial conversations, making transparency and ambitious targets resources rather than constraints. This approach helps managers act as integrators, **leveraging cooperation** and rich information to achieve superior results.

### Rewarding Cooperation Through Architecture Practice

Architecture practice can facilitate rewarding cooperation by making it easier for individuals to help others and ask for help:

* A strong **[Collaborative Networks](people)** can provide the context and networks necessary for easier collaboration.
* Adding diverse data sources to **[Lightweight Architectural Analytics](analytics)** can create transparency about cooperation opportunities and challenges, supporting a more collaborative environment.

<br>
## To Probe Further
* [Six Simple Rules: How to Manage Complexity without Getting Complicated](https://www.bcg.com/capabilities/organization-strategy/smart-simplicity)


<br>
## Questions to Consider

* *How can the concept of Smart Simplicity apply to your current role or position within your organization?*
* *Do you feel the structures, processes, and systems directly and predictably affect performance in your organization?*
* *Do you feel that your organization views the human factor is viewed as the weakest link? How does this affect how you and your colleagues perform?*
* *How do you perceive the balance between your organization's hard and soft management approaches? Is one approach more dominant?*
* *How does your organization currently promote autonomy and cooperation among employees? Are there areas for improvement?*
* *How do the assumptions of hard and soft management approaches hinder cooperation in your organization?*
* *How can you increase the total power within your organization without taking power away from others?*
* *How can your organization increase reciprocity and make each person's success dependent on the success of others?*
* *How can your organization extend the shadow of the future? Are there feedback mechanisms in place to make people accountable for their decisions?*
* *How are those who cooperate rewarded in your organization? Are there mechanisms in place to increase the payoff for all when they cooperate beneficially?*
* *How can architecture practice in your organization support the implementation of the Six Simple Rules?*
* *How do your organization's current systems and structures promote or hinder the cooperation needed to make autonomy effective?*

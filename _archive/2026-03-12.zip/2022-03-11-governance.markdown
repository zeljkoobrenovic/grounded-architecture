---
layout: post
section: "Grounded Architecture Framework: Operating Model"
title: "Governance Principles: Nudges, Taxation, Mandates"
position: 3011
podcast: governance.mp3
spotify: https://open.spotify.com/episode/2UTAYFVJoWRmvX5CvJsJST?si=83969e560b6c4886
date:   2021-10-21 21:12:01 +0100
author: by Željko Obrenović (obren.io)
icon: govern.png
permalink: governance
timetoread: 15 min
excerpt: "Architecture practice should support governance models that are adaptable to organizations' complex and diverse needs. I see a technology governance model as a well-balanced hybrid of three different styles of governing: nudging, taxes, and mandates and bans."

---
<img style="margin-top: -20px; width: 100%; height: 400px; object-fit: cover" 
     src="assets/images/arch/greece-1594689_1920.jpg">
<div style="font-size: 70%; margin-top: -16px; color: grey; margin-bottom: 12px">
Image by <a href="https://pixabay.com/nl/users/nonbirinonko-3101900/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=1594689">nonbirinonko</a> from <a href="https://pixabay.com/nl//?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=1594689">Pixabay</a>
</div>
> **IN THIS SECTION, YOU WILL:** Understand that a technology governance model should be a well-balanced hybrid of three different styles of governing: mandates and bans, taxes, and nudging.
>
> **KEY POINTS:**
>
> * Architecture practice should support governance models adaptable to organizations' complex and diverse needs. A technology governance model should be a well-balanced hybrid of three different styles of governing: mandates and bans, taxes, and nudging.
> * Nudging is a form of governing where you create subtle or indirect suggestions influencing someone's behavior or decision-making without forcing them or limiting their freedom of choice.
> * Governing with taxes (economic incentives) is a form of guiding in which people are not forbidden to make some decisions but need to "pay" some form of taxes on used resources.
> * With mandates and bans, you guide people by explicitly defining what they should or should not do.
<style>
 .quote {
     border-left: 8px solid #d9ead3;
     padding-left: 36px;
     margin-top: 30px;
     margin-bottom: 40px;
     font-size: 140%;
     font-style: normal;
     color:#888;
 }
    @media only screen and (max-width: 768px) {
        [class="quote"] {
            display: none;
        }
    }
     h3 {
          margin-top: 26px;     
     }
</style>

<br>
Governance is all about the **rules, practices, and processes** that guide how an organization is run, managed, and held accountable. It helps clarify who makes decisions, how those decisions are made, and how we monitor and enforce the outcomes.

But governance isn't just about the big meetings at the top; it's essential throughout the organization and touches on various areas like:

- **Corporate governance**, which helps steer leadership and accountability.
- **IT governance**, ensuring that tech investments align with business goals.
- **Project governance**, focusing on managing projects to ensure they meet strategic targets.
- **Data governance**, making sure data is accurate, secure, and used responsibly.

<br>
## IT Governance

IT architecture is also about governance. Think about what IT architecture does for an organization:

- It **reduces complexity** by helping **standardize** systems and processes.
- It ensures that technology is **aligned with business priorities**.
- It helps **manage risks** related to security, compliance, and organizational changes.
- It allows for **efficient resource use**, avoiding waste.
- It supports better **decision-making** by providing clear structures and insights.
- It opens the door for **innovation** without losing control.
- It helps **measure performance** and encourages continuous improvement.

IT architecture plays a vital role in bringing governance principles to life through practical, everyday practices that drive business success with technology.

The best governance frameworks are like **living systems**; they evolve as the organization grows and its environment changes. For governance to work, it needs to be:

- **Adaptable**—able to adjust as needs evolve.
- **Collaborative**—bringing together different voices and perspectives.
- **Strategic**—finding the right balance between immediate needs and long-term goals.

When it comes to IT architecture, it should support governance models that can deal with the complexity and diversity of today's organizations. A one-size-fits-all approach typically doesn't cut it. That's why I'm a fan of a **hybrid governance model**—a mix of different strategies tailored to specific situations.

This model uses three types of influence:

1. **Nudging**—providing gentle guidance that helps steer behavior without restricting choices.
2. **Taxes** (or economic incentives)—rewarding good behavior or discouraging bad practices through resource management.
3. **Mandates and bans**—setting clear rules and boundaries when necessary.

All these approaches work together to create a flexible and practical framework that helps manage the use and development of technology within the organization.

Let's explore each of these governance styles in more detail, starting with **nudging**. 

<br>
## Nudging as a Governance Tool

In behavioral economics and psychology, a **nudge** refers to a subtle cue or indirect suggestion that influences how people behave or make decisions—**without coercing them or limiting their choices**. The effectiveness of nudging lies in its gentle influence: it respects individual freedom while encouraging better choices through thoughtful design, context, and feedback.

<br>
<img style="margin-top: -20px; width: 100%; height: 400px; object-fit: cover" 
     src="assets/images/istock/iStock-1390608248.jpg">
<div style="font-size: 70%; margin-top: -16px; color: grey; margin-bottom: 12px">
Image by <a target="_blank" href="https://www.istockphoto.com/en/portfolio/Chernetskaya">Liudmila Chernetska</a> from <a target="_blank" href="https://www.istockphoto.com/">iStock</a>
</div>

### What are Nudges?

Nudges are frequently utilized in areas such as public policy, marketing, and workplace culture to assist individuals in making decisions that lead to better outcomes—both for themselves and for the system as a whole. Common examples include:

* **Placing healthy food at eye level** in cafeterias to encourage healthier eating habits.
* **Setting default options** (e.g., opt-out organ donation) to promote socially beneficial behavior.
* **Sending reminders** or prompts to encourage timely actions, such as saving for retirement or updating software.

This concept gained global attention through the book ***Nudge: Improving Decisions About Health, Wealth, and Happiness*** by **Richard Thaler and Cass Sunstein**. They also introduced the idea of **choice architecture**—how the structure and presentation of choices influence decision-making. By designing the environments in which decisions are made, we can gently guide behavior toward better outcomes, often overcoming common cognitive biases.

### Nudging in IT Architecture

In the realm of **IT architecture**, nudging serves as a powerful, non-intrusive method to guide teams and individuals toward more consistent, efficient, and aligned behavior—**without enforcing strict compliance**.

Here are some ways nudging manifests in architectural practice:

* **Architectural principles**:
  Serve as soft guidelines rather than hard rules, subtly encouraging teams to align with broader strategic goals.

* **Best practice recommendations**:
  Promote reuse, consistency, and improved quality across teams while still allowing for autonomy.

* **Golden paths**:
  Predefined, well-supported solutions or workflows that are the easiest to follow, gently guiding teams toward preferred technology choices. ([Spotify’s golden paths](https://engineering.atspotify.com/2020/08/how-we-use-golden-paths-to-solve-fragmentation-in-our-software-ecosystem/) are a strong example.)

* **Dashboards and visualizations**:
  Lightweight analytics platforms can highlight outdated or poor-quality software, applying social and reputational pressure for improvement without direct enforcement.

* **Technical debt tracking**:
  Making technical debt visible raises awareness and nudges teams to address it over time.

* **Cloud cost visualizations**:
  Demonstrating cost trends per team encourages behavior that leads to greater efficiency in cloud usage.

These nudges are most effective when they are **transparent, actionable, and connected to meaningful outcomes**. They constructively influence behavior—helping people and teams make smarter decisions **without the burden of top-down mandates** or punitive enforcement.

The principles of **Grounded Architecture** closely align with the concept of nudging. Instead of imposing rigid control, it creates environments that organically and collaboratively guide behavior. For instance:

* **[Lightweight Architectural Analytics](analytics)** tools are designed to highlight areas that need improvement—acting as cues rather than commands.
* **[Collaborative Networks](people)** encourage peer learning and the dissemination of best practices through community influence and storytelling.
* The **[Operating Model](operating-model)** promotes autonomous decision-making while integrating subtle mechanisms that **nudge alignment** with strategic goals.

Together, these approaches create a governance strategy that is **flexible, respects autonomy**, and is **highly effective** in complex, dynamic organizational settings.


<br>
## Taxation (Economic Incentives) as a Governance Mechanism

**Taxation as governance** is an approach that promotes accountability without imposing restrictions. Instead of prohibiting specific actions, it allows teams or departments to make their own decisions—but with **a cost**. This “cost,” or **tax**, is typically linked to the resources they consume. It creates a **feedback loop** that helps regulate behavior by making the consequences of excessive usage visible and tangible.

A common and effective example of this is found in **managing cloud costs**. In many organizations, departments consume public cloud services, such as storage, computation, and bandwidth. When these expenses are **cross-charged**—meaning each department pays for its share of usage—it sends a **clear signal about resource consumption**. Teams become more aware of their costs and are motivated to avoid waste and optimize efficiency.

<br>
<img style="margin-top: -20px; width: 100%; height: 400px; object-fit: cover" 
  src="assets/images/arch/credit-squeeze-g61ddead85_1920.png">

<div style="font-size: 70%; margin-top: -16px; color: grey; margin-bottom: 12px">
Image by <a href="https://pixabay.com/users/stevepb-282134/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=522549">Steve Buissinne</a> from <a href="https://pixabay.com//?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=522549">Pixabay</a>
</div>

This approach contrasts with **nudging**, which uses subtle design cues and informational guidance. Taxation, on the other hand, introduces **direct, measurable consequences**. For example, if a project consistently exceeds its allocated cloud budget, it may be **delayed, reviewed, or even canceled**. This adds a layer of accountability to resource use while still preserving team autonomy.

### The Role of Architecture in a Taxation Model

The architecture practice plays a **critical role** in supporting this governance approach by ensuring that **taxation mechanisms are fair, transparent, and data-driven**. Key elements include:

* **Transparent reporting**:
  All stakeholders must clearly understand how resource consumption is measured, how costs are allocated, and how these factors impact decision-making. This transparency builds trust and supports behavior change.

* **Accurate, comprehensive data**:
  Taxation should be based on actual usage patterns, not estimates. Detailed cost reports—especially from public cloud environments—form the basis of meaningful economic incentives.

* **Timely feedback loops**:
  Teams need **real-time or near-real-time insights** into their resource usage and associated costs. When feedback is delayed or unclear, the effectiveness of the tax diminishes.

* **Lightweight Architectural Analytics**:
  Tools like [Lightweight Architectural Analytics](analytics) aggregate cloud cost data, visualize spending patterns, and help identify optimization opportunities. These analytics transform raw data into **actionable insights**.

* **Collaborative Networks**:
  [Collaborative Networks](people) align teams around shared goals, support the interpretation of analytics data, and facilitate the exchange of ideas for optimizing usage. They help foster a **culture of responsible resource management**.

### Driving Sustainable Change

Ultimately, governing with taxes enables organizations to balance **autonomy with accountability**. It allows teams the freedom to make choices while making the **impact of those choices visible** through economic signals. When implemented effectively, this approach:

* Encourages **cost-conscious decision-making**.
* Discourages **wasteful or unsustainable use** of shared resources.
* Promotes **optimization and innovation** within constraints.
* Strengthens alignment between **financial accountability** and **technical architecture**.

With the right tools and structures in place—such as Lightweight Architectural Analytics and Collaborative Networks—**architecture practices become essential enablers** of this governance style. They ensure that economic incentives are used wisely, feedback is timely, and resource consumption aligns with the organization’s long-term goals.





<br>
## Mandates and Bans as Governance Tools

**Mandates and bans** are the most direct forms of governance. They clearly specify what people **must do** (mandates) or **must not do** (bans). These tools are essential for defining **non-negotiable rules and boundaries**, particularly in areas where compliance, ethics, or risk mitigation are crucial.

In practice, mandates and bans play a **limited but vital role** in shaping behavior. For example:

* A company may **restrict the use of certain cloud providers** to ensure data sovereignty or contractual compliance.
* Legal and regulatory mandates may **require strong encryption**, privacy protection, or specific financial reporting standards.
* Specific bans may **prohibit risky technologies or architectural patterns** that have proven unsustainable or insecure.

<br>
<img style="margin-top: -20px; width: 100%; height: 400px; object-fit: cover" 
  src="assets/images/arch/ethics-g277df4183_1920.jpg">

<div style="font-size: 70%; margin-top: -16px; color: grey; margin-bottom: 12px">
Image by <a href="https://pixabay.com/users/tumisu-148124/?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=2991600">Tumisu</a> from <a href="https://pixabay.com//?utm_source=link-attribution&amp;utm_medium=referral&amp;utm_campaign=image&amp;utm_content=2991600">Pixabay</a>
</div>

While mandates and bans can be powerful, they should be used **sparingly and intentionally**. Overusing them may create unnecessary friction, discourage innovation, or diminish trust. However, in areas like **security, compliance, and ethics**, clear rules are not just helpful—they are essential. These rules help prevent incidents, safeguard the organization's reputation, and **ensure adherence to laws and regulations**.

### The Role of Architecture in Enforcing Mandates and Bans

In this governance model, the **architecture practice serves as a contributor—not the sole authority**. Mandates and bans are typically shaped collaboratively with:

* **Security and risk teams** to address vulnerabilities and ensure compliance.
* **Legal and regulatory departments** to adhere to external obligations.
* **Operations and finance** to enforce constraints related to costs or performance.

The architecture team’s role is to **clarify, document, and reinforce** these mandates through guidance, tooling, and visibility:

* **Lightweight Architectural Analytics**:  
  [Lightweight Architectural Analytics](analytics) helps identify areas that require monitoring or enforcement. It can surface security vulnerabilities, policy violations, or infrastructure risks through dashboards and reports—creating **transparency and focus**.

* **Collaborative Networks**:  
  [Collaborative Networks](people) are essential for the **socialization and adoption** of mandates. They help explain the reasoning behind new rules, build consensus, and foster acceptance. These networks ensure that changes are **well-communicated, understood, and internalized**—not just enforced.

### When and How to Use Mandates and Bans

Mandates and bans are best reserved for:

* **Critical compliance needs** (e.g., GDPR, financial regulations)
* **Organizational priorities** (e.g., sustainability, cybersecurity)
* **Strategic constraints** (e.g., vendor lock-in, architectural standards)

They work most effectively when:

* Stakeholders are **engaged early in the process**.
* There is **clear, data-driven justification**.
* Communication is **open, empathetic, and thorough**.
* There are **mechanisms to track adherence and measure impact**.

Governing with mandates and bans involves setting **firm, transparent boundaries**, but this should be done with care. This governance tool is best employed when other methods (like nudging or taxation) are insufficient to ensure compliance, protect the organization, or uphold its values.

When thoughtfully implemented, and supported by clear analytics and strong collaboration, mandates and bans can become **protective measures**, not roadblocks—**enabling safe innovation** within a framework of trust and responsibility.

<br>
## Questions to Consider

* *What are the key components of the governance model in your organization, and how do mandates, taxes, and nudging influence them?*
* *How does your organization currently handle mandates and bans? Are they explicit and aligned with the overall technology strategy?*
* *How effective is the enforcement of these mandates and bans in your organization? Could improvements be made to create clarity and provide transparency?*
* *How does your organization approach taxation as a form of governance? Is it transparent, data-driven, and efficient?*
* *Can you identify any examples of 'nudging' in your current architectural environment? How effective are these subtle suggestions in influencing behavior or decision-making?*
* *How does your organization promote best practices and align around them? Are there any 'golden paths' for technology choices?*
* *How are your organization's tech debt and the cost trends of cloud services tracked and visualized? Do these methods create enough awareness to stimulate improvement?*
* *How could you better utilize nudging to improve organizational decision-making? What biases or barriers to effective decision-making could you target with this approach?*
